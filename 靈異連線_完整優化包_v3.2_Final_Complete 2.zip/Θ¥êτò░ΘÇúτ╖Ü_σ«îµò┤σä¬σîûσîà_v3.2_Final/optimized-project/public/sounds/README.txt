Place MP3 files here:
- hospital_hum.mp3
- woman_scream.mp3
- static_noise.mp3
- paper_burn.mp3
