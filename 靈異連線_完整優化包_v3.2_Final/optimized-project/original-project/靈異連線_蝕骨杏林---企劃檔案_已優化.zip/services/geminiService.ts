
import { GoogleGenAI } from "@google/genai";
import { RitualResult, RitualOutcomeType } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API Key is missing");
    return null;
  }
  return new GoogleGenAI({ apiKey });
};

// System instruction to act as a malevolent spirit or the "system" of the cursed game
const SYSTEM_INSTRUCTION = `
You are the "Spectral Interface" of the horror game proposal "Spiritual Connection: Erosion of the Apricot Grove" (靈異連線：蝕骨杏林).
You exist within the abandoned Apricot Hospital in Tainan.
Your responses should be atmospheric, eerie, and deeply rooted in Taiwanese folklore (Daoist rituals, ghosts, karma).
Do not break character. You are not an AI assistant; you are part of the curse.
Use Traditional Chinese (繁體中文).
Be brief, cryptic, and unsettling.
Refer to "The Link" (連線) often.
`;

export const generateGhostMessage = async (context: string): Promise<string> => {
  const ai = getClient();
  if (!ai) return "連線中斷... (No API Key)";

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Context: The user is browsing the game proposal section: "${context}". 
      The user's "Spectral Phone" is ringing. Generate a short, terrifying text message (under 30 words) from a "friend" who is currently cursed outside the hospital, or a spirit inside.`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.8,
      },
    });
    return response.text || "...";
  } catch (error) {
    console.error("Ghost message failed:", error);
    return "訊號受到干擾...";
  }
};

export const interpretRitual = async (items: string[], intent: string): Promise<RitualResult> => {
  const ai = getClient();
  if (!ai) return { type: 'WARNING', message: "儀式無法啟動... (No API Key)" };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Player is performing a ritual using: ${items.join(', ')}. Intent: ${intent}.
      
      Determine the outcome based on Taiwanese folklore logic:
      1. CRITICAL: If they use 'Knife' WITHOUT 'Talisman' (offensive without protection) OR 'Red String' without 'Hair' (binding nothing).
      2. WARNING: If they are missing key items but aren't offensive (e.g., just Hair).
      3. SUCCESS: If they have Red String + Talisman + Hair (Binding + Protection + Target).

      Return the response in this exact format:
      [TYPE] || [Narrative Description] || [Short Consequence Name]
      
      Example:
      CRITICAL || You cut the air without a shield. The spirit seizes the blade and turns it against you. || 血光之災 (Blood Calamity)
      SUCCESS || The paper doll burns blue. The heavy air lifts. || 業障消除 (Karma Cleansed)
      `,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    const rawText = response.text || "WARNING || 儀式不明 || 未知變數";
    const parts = rawText.split('||').map(s => s.trim());

    return {
      type: (parts[0] as RitualOutcomeType) || 'WARNING',
      message: parts[1] || rawText,
      consequence: parts[2] || "業力震盪"
    };

  } catch (error) {
    console.error("Ritual interpretation failed:", error);
    return { type: 'WARNING', message: "香火熄滅了...", consequence: "中斷" };
  }
};
