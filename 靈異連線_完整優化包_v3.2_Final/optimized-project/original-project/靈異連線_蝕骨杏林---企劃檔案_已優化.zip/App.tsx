import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  MapPin,
  FileText,
  Skull,
  BookOpen,
  Activity,
  AlertCircle,
  Play,
  Sparkles,
  Users,
  Gift,
  CalendarClock,
  HelpCircle,
  ExternalLink,
  BadgeCheck
} from 'lucide-react';

import SectionHeader from './components/SectionHeader';
import GlitchText from './components/GlitchText';
import ClueTrigger from './components/ClueTrigger';
import ClueJournal from './components/ClueJournal';
import SpectralPhone from './components/SpectralPhone';
import RitualCanvas from './components/RitualCanvas';
import { Clue, PlayerDebuff, RitualResult } from './types';

const App: React.FC = () => {
  const contentRef = useRef<HTMLElement | null>(null);

  // UI state
  const [isJournalOpen, setIsJournalOpen] = useState(false);

  // Atmosphere state
  const [fearLevel, setFearLevel] = useState(10);
  const [debuffs, setDebuffs] = useState<PlayerDebuff[]>([]);
  const debuffTimeouts = useRef<Record<string, number>>({});

  useEffect(() => {
    return () => {
      // 清掉所有 timeout，避免切頁/熱更新時留下幽靈計時器
      Object.values(debuffTimeouts.current).forEach(t => window.clearTimeout(t));
    };
  }, []);
  const [currentSection, setCurrentSection] = useState('英雄區塊');

  // Evidence / Clues (可持續擴充；每個 clue 可用 ClueTrigger 觸發)
  const [clues, setClues] = useState<Clue[]>([
    {
      id: 'c1',
      title: '樓層導覽圖：四樓不存在',
      type: 'document',
      found: false,
      content:
        '醫院共有七層樓，卻沒有「四樓」——樓層標示用「○」。
地下室入口標著「太平門」，走進去像踏進另一個世界。',
      description: '建築細節比鬼故事更可怕：因為它是真的。'
    },
    {
      id: 'c2',
      title: '燒焦的血符殘片',
      type: 'photo',
      found: false,
      content:
        '紙張邊緣像被指甲刮過。
朱砂暈開成一個不規則的人形。
你聞到香灰——但這裡沒有香爐。',
      description: '符咒不是保護。符咒是交易。'
    },
    {
      id: 'c3',
      title: '監視器截圖：中庭天井的陰影',
      type: 'photo',
      found: false,
      content:
        '畫面來源：SURVEILLANCE CAM 04。
天井光線垂直落下，但陰影的方向是水平的。
像有什麼東西，站在光裡。',
      description: '光不是安全。光只是讓你看清你在害怕什麼。'
    },
    {
      id: 'c4',
      title: '停業公文：時間被封存',
      type: 'document',
      found: false,
      content:
        '1993/06/01：勒令停業。
1993/08/21：正式廢業。
最詭異的是——器械、藥品、病歷像被時間「凍結」在原地。',
      description: '人走了，流程沒走。流程才是詛咒。'
    },
    {
      id: 'c5',
      title: '來電記錄：太平門的求救聲',
      type: 'document',
      found: false,
      content:
        '2015 年。
兩名闖入者在太平間打卡後，接到未知來電。
通話內容只有一句：「快來救救我。」',
      description: '電話不是求救。電話是連線。'
    }
  const foundIds = useMemo(() => new Set(clues.filter(c => c.found).map(c => c.id)), [clues]);

  ]);

  const sections = useMemo(
    () => [
      { id: 'hero', label: '英雄區塊' },
      { id: 'hook', label: 'Hook影片' },
      { id: 'overview', label: '快速概覽' },
      { id: 'story', label: '故事與背景' },
      { id: 'gameplay', label: '玩法與系統' },
      { id: 'aesthetics', label: '聲光美學' },
      { id: 'team', label: '團隊' },
      { id: 'rewards', label: '獎勵方案' },
      { id: 'roadmap', label: '時程/路線圖' },
      { id: 'faq', label: 'FAQ' }
    ],
    []
  );

  // Scroll spy：優先使用 IntersectionObserver（更省效能），不支援則 fallback 到 scroll + rAF。
  useEffect(() => {
    const els = sections
      .map(s => document.getElementById(s.id))
      .filter(Boolean) as HTMLElement[];

    // Fallback（極少數舊瀏覽器）
    if (!('IntersectionObserver' in window) || els.length === 0) {
      let ticking = false;
      const handleScroll = () => {
        if (ticking) return;
        ticking = true;
        window.requestAnimationFrame(() => {
          const y = window.scrollY + 220; // 稍微提前觸發，手感比較自然
          let active = sections[0];

          for (const s of sections) {
            const el = document.getElementById(s.id);
            if (el && y >= el.offsetTop) active = s;
          }
          setCurrentSection(active.label);
          ticking = false;
        });
      };

      window.addEventListener('scroll', handleScroll, { passive: true });
      handleScroll();
      return () => window.removeEventListener('scroll', handleScroll);
    }

    const idToLabel = new Map(sections.map(s => [s.id, s.label] as const));

    const observer = new IntersectionObserver(
      entries => {
        const visible = entries
          .filter(e => e.isIntersecting)
          // 越靠近上方越優先
          .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top);

        if (visible.length === 0) return;

        const id = (visible[0].target as HTMLElement).id;
        const label = idToLabel.get(id);
        if (label) setCurrentSection(label);
      },
      {
        root: null,
        threshold: [0.1, 0.25, 0.5],
        // 讓「接近視窗上方」的 section 更容易被視為目前章節
        rootMargin: '-20% 0px -70% 0px'
      }
    );

    els.forEach(el => observer.observe(el));

    // Initialize（避免剛載入時 nav 空轉）
    const init = () => {
      const candidate = els
        .map(el => ({ el, top: el.getBoundingClientRect().top }))
        .filter(x => x.top < window.innerHeight)
        .sort((a, b) => Math.abs(a.top) - Math.abs(b.top))[0];

      if (!candidate) return;
      const label = idToLabel.get(candidate.el.id);
      if (label) setCurrentSection(label);
    };
    init();

    return () => observer.disconnect();
  }, [sections]);

  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (!el) return;
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const revealClue = (id: string) => {
    setClues(prev => prev.map(c => (c.id === id ? { ...c, found: true } : c)));
  };

  // Global callbacks for interactive elements
  const handleFearIncrease = (amount: number) => {
    setFearLevel(prev => Math.min(100, prev + amount));
  };

  const addDebuff = (debuff: PlayerDebuff, duration: number) => {
    setDebuffs(prev => (prev.includes(debuff) ? prev : [...prev, debuff]));

    const key = String(debuff);
    const existing = debuffTimeouts.current[key];
    if (existing) window.clearTimeout(existing);

    debuffTimeouts.current[key] = window.setTimeout(() => {
      setDebuffs(prev => prev.filter(d => d !== debuff));
      delete debuffTimeouts.current[key];
    }, duration);
  };

  const handleRitualOutcome = (result: RitualResult) => {
    if (result.type === 'CRITICAL') {
      handleFearIncrease(30);
      addDebuff('SHAKY_HANDS', 15000);
    } else if (result.type === 'WARNING') {
      handleFearIncrease(10);
    } else {
      // SUCCESS reduces fear a bit
      setFearLevel(prev => Math.max(0, prev - 10));
    }
  };

  const rewards = [
    {
      price: 'NT$100',
      name: '守望者',
      tag: '致謝入列',
      includes: ['特別感謝', '製作名單收錄']
    },
    {
      price: 'NT$450',
      name: '探求者',
      tag: '數位入場',
      includes: ['遊戲數位版（發售時）', '數位桌布']
    },
    {
      price: 'NT$750',
      name: '通靈者',
      tag: '世界觀補完',
      includes: ['遊戲數位版', 'OST（數位）', '設定集（數位）']
    },
    {
      price: 'NT$1,500',
      name: '驅魔師',
      tag: '實體收藏',
      includes: ['實體設定集', '全數位內容（含OST、桌布）']
    },
    {
      price: 'NT$3,000',
      name: '除煞師',
      tag: '典藏限定',
      includes: ['限量典藏版', '獨家周邊（符咒/老照片/包裝等）']
    }
  ];

  const faq = [
    {
      q: '這是「真實故事改編」嗎？',
      a: '我們採用較安全的定位：靈感取材自台灣醫院的都市傳說與民俗文化，避免做出無法驗證、可能被質疑的具體聲明。'
    },
    {
      q: '募資期間會有 Demo 嗎？',
      a: '建議準備可玩 Demo；它已經是恐怖遊戲募資的基本配備，能大幅提升信任與轉換。'
    },
    {
      q: '會在哪些平台發售？',
      a: '（請填）PC/Steam、主機、行動裝置等。建議先以最小可行範圍（MVP）承諾，再逐步擴張。'
    },
    {
      q: '更新頻率？',
      a: '建議募資期間每週更新；募資結束後每月更新一次，並公開里程碑。'
    },
    {
      q: '你們會做什麼「恐怖專屬回饋」？',
      a: '可以設計「贊助者鬼魂/NPC」、「命名房間」、「世界觀文件」、「受詛咒包裝」或實體道具（符咒、老照片）。'
    }
  ];

  return (
    <div className="min-h-screen bg-black text-stone-300 relative overflow-x-hidden">
      {/* Background */}
      <div className="fixed inset-0 z-0 opacity-20">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_30%,rgba(127,29,29,0.45),transparent_55%)]"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/noise.png')] mix-blend-overlay"></div>
      </div>

      {/* Clue Journal Modal */}
      <ClueJournal clues={clues} isOpen={isJournalOpen} onClose={() => setIsJournalOpen(false)} />

      {/* Debuff HUD */}
      {debuffs.length > 0 && (
        <div className="fixed top-20 right-4 z-40 flex flex-col gap-2 items-end">
          {debuffs.map(d => (
            <div
              key={d}
              className="bg-red-950/80 border-r-2 border-red-600 text-red-200 px-3 py-1 text-xs font-mono uppercase animate-pulse flex items-center gap-2"
            >
              <AlertCircle size={12} />
              {d.replace('_', ' ')}
            </div>
          ))}
        </div>
      )}

      {/* Header */}
      <header className="fixed top-0 left-0 w-full z-40 bg-black/80 backdrop-blur-sm border-b border-stone-900 p-4 flex justify-between items-center">
        <button
          onClick={() => scrollTo('hero')}
          className="font-mincho font-black text-stone-200 hover:text-red-500 transition-colors"
          title="回到頂部"
        >
          靈異連線：蝕骨杏林
        </button>

        <div className="hidden lg:flex items-center gap-2 text-xs font-mono">
          {sections.map(s => (
            <button
              key={s.id}
              onClick={() => scrollTo(s.id)}
              className={`px-2 py-1 border rounded transition-colors ${
                currentSection === s.label
                  ? 'border-red-900/70 text-red-300 bg-red-950/20'
                  : 'border-stone-800 text-stone-500 hover:text-stone-200 hover:border-stone-600'
              }`}
            >
              {s.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setIsJournalOpen(true)}
            className="flex items-center gap-2 text-stone-400 hover:text-red-500 transition-colors"
          >
            <BookOpen size={18} />
            <span className="text-xs font-mono hidden md:inline">
              EVIDENCE ({clues.filter(c => c.found).length}/{clues.length})
            </span>
          </button>

          <div className="text-xs text-red-800 font-mono animate-pulse flex items-center gap-2">
            <Activity size={12} />
            <span className="hidden md:inline">PARANORMAL ACTIVITY DETECTED</span>
          </div>
        </div>
      </header>

      {/* Main */}
      <main ref={contentRef} className="relative z-10 max-w-5xl mx-auto px-6 py-24 pb-56">
        {/* Hero */}
        <section id="hero" className="mb-20 scroll-mt-24">
          <div className="text-red-700 text-sm font-mono mb-2">CLASSIFIED // CROWDFUNDING_PAGE_V1.2</div>

          <h1 className="text-4xl md:text-6xl font-mincho font-black text-stone-100 mb-6 leading-tight">
            <GlitchText text="當符咒失效" intensity="high" /> <span className="text-stone-600">你只剩本命燈</span>
          </h1>

          <p className="text-lg md:text-xl leading-relaxed text-stone-400 border-l-4 border-stone-800 pl-6 italic">
            《靈異連線：蝕骨杏林》是一款第一人稱沉浸式恐怖生存遊戲，取材自台灣醫院都市傳說與民俗「祭改」文化——
            你不是英雄，你只是被迫「照流程」的人。
          </p>

          <div className="mt-10 flex flex-col md:flex-row gap-4">
            <button className="px-6 py-3 bg-red-900/30 border border-red-900/60 text-red-100 hover:bg-red-900/50 transition-colors flex items-center justify-center gap-2">
              <BadgeCheck size={18} />
              加入願望清單（填入連結）
              <ExternalLink size={16} className="opacity-60" />
            </button>
            <button className="px-6 py-3 bg-stone-900/40 border border-stone-800 text-stone-200 hover:border-stone-600 transition-colors flex items-center justify-center gap-2">
              <Play size={18} />
              下載 Demo（填入連結）
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            {[
              { title: '連鎖詛咒', desc: '恐懼不只在場內。你被咬，你的朋友也會在現實流血。' },
              { title: '擬真祭改流程', desc: '寫疏文、用印、燒金、替身承厄——少一步就多一條命。' },
              { title: '本命燈', desc: '燈火越暗，世界越真。燈滅，不只是死亡。' }
            ].map((usp, i) => (
              <div key={i} className="bg-stone-900/50 p-6 border border-stone-800 hover:border-red-900/50 transition-colors">
                <h3 className="text-lg font-bold text-stone-200 mb-2">{usp.title}</h3>
                <p className="text-sm text-stone-500">{usp.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Hook video */}
        <SectionHeader title="Hook 影片" subtitle="TRAILER (1.5–3 MIN)" />
        <section id="hook" className="mb-20 scroll-mt-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-start">
            <div className="aspect-video w-full bg-stone-950 border border-stone-800 relative overflow-hidden">
              <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(127,29,29,0.25),transparent_60%)]"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="inline-flex items-center gap-2 px-3 py-1 text-xs font-mono border border-stone-700 text-stone-400 bg-black/40">
                    <Play size={14} />
                    置入 Hook 影片（YouTube / Vimeo）
                  </div>
                  <div className="mt-4 text-stone-600 text-xs font-mono">
                    0–15 秒：最狠亮點 / 15–60 秒：這是什麼 / 60–120 秒：實機 / 最後：團隊 + CTA
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-stone-900/40 border border-stone-800 p-6">
              <h3 className="font-mincho text-xl text-stone-200 mb-3">開場一句話</h3>
              <p className="text-stone-500 leading-relaxed">
                1993 年，台南某間醫院在一夜之間人去樓空——器械與病歷原封不動，像時間被封存。三十年後，你收到一通電話。
                <ClueTrigger id="c4" found={foundIds.has('c4')} onReveal={revealClue} />
              </p>

              <div className="mt-6 border-t border-stone-800 pt-6">
                <div className="text-xs font-mono text-stone-500 mb-2">建議放這三個畫面：</div>
                <ul className="space-y-2 text-sm text-stone-500 list-disc pl-5">
                  <li>天井垂直光柱，陰影卻橫向移動（空間錯覺）<ClueTrigger id="c3" found={foundIds.has('c3')} onReveal={revealClue} /></li>
                  <li>太平門走廊，牆上手印與掉落符紙（儀式痕跡）</li>
                  <li>本命燈忽明忽暗，字幕只打一行：燈滅，連線完成。</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Overview */}
        <SectionHeader title="快速概覽" subtitle="CORE FEATURES" />
        <section id="overview" className="mb-20 scroll-mt-24">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { title: '可玩 Demo', icon: <Play size={18} />, desc: '募資頁面最需要的不是承諾，是你真的能玩到。' },
              { title: '本命燈資源', icon: <Sparkles size={18} />, desc: '燈火明亮→鬼魅難近；燈火搖曳→黑暗蠢動；燈滅→代價入帳。' },
              { title: '祭改儀式互動', icon: <FileText size={18} />, desc: '供品、替身、符咒、禁忌——每個細節都能讓你活下來或更快死。' },
              { title: '連線：場外恐怖', icon: <Activity size={18} />, desc: '你以為離開醫院就安全？連線才剛開始。' },
              { title: '在地場域還原', icon: <MapPin size={18} />, desc: '七層樓、中庭天井、四樓標成「○」、地下室太平門。' },
              { title: '多結局與代償', icon: <Skull size={18} />, desc: '結局不是好壞，是你願意付多少。' }
            ].map((f, i) => (
              <div key={i} className="bg-stone-900/30 p-6 border border-stone-800 hover:border-stone-600 transition-colors">
                <div className="flex items-center gap-2 text-stone-300 mb-3">
                  <span className="text-red-800">{f.icon}</span>
                  <h3 className="font-bold">{f.title}</h3>
                </div>
                <p className="text-sm leading-relaxed text-stone-500">{f.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Story */}
        <SectionHeader title="故事與背景" subtitle="WHY THIS GAME" />
        <section id="story" className="mb-20 scroll-mt-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-start">
            <div className="prose prose-invert prose-stone max-w-none">
              <p>
                你不是來「破關」的，你是來「收拾」。一間廢棄醫院像病灶一樣長在城市裡，怨氣堆積、流程殘留，
                連錯置的樓層符號都成了詛咒的語法。
              </p>
              <p>
                我們採用安全且可被信任的敘事立場：靈感取材自台灣醫療都市傳說與宮廟民俗，並以「文化真實性」為最高優先，
                避免把故事包裝成無法驗證的「真實改編」。
              </p>
              <p className="text-stone-500">
                2015 年，有人闖入太平間打卡後接到未知來電，電話裡傳出一句話：「快來救救我。」<ClueTrigger id="c5" found={foundIds.has('c5')} onReveal={revealClue} />
              </p>
            </div>

            <div className="bg-stone-900/30 border border-stone-800 p-6">
              <h3 className="font-mincho text-xl text-stone-200 mb-4">場域原型（可直接放募資頁）</h3>
              <ul className="space-y-3 text-sm text-stone-500">
                <li className="flex items-start gap-3">
                  <MapPin size={16} className="mt-1 text-red-800" />
                  <span>
                    1975 創立，七層樓建築；中庭天井讓光線垂直灌入，形成強烈空間壓迫。<ClueTrigger id="c3" found={foundIds.has('c3')} onReveal={revealClue} />
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <FileText size={16} className="mt-1 text-red-800" />
                  <span>
                    四樓忌諱諧音改標示「○」，地下室設「太平門」（太平間）。<ClueTrigger id="c1" found={foundIds.has('c1')} onReveal={revealClue} />
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <AlertCircle size={16} className="mt-1 text-red-800" />
                  <span>
                    1993 停業/廢業後，設備與病歷大量留置，形成「時間凍結」的恐怖舞台。<ClueTrigger id="c4" found={foundIds.has('c4')} onReveal={revealClue} />
                  </span>
                </li>
              </ul>

              <div className="mt-6 border-t border-stone-800 pt-6">
                <div className="text-xs font-mono text-stone-500 mb-2">一句定位（可直接貼）</div>
                <div className="p-4 bg-black/30 border border-stone-800 text-stone-300 italic leading-relaxed">
                  「結合台灣宮廟文化的心理恐怖生存遊戲：當符咒失效，你只剩本命燈。」
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Gameplay */}
        <SectionHeader title="玩法與系統" subtitle="RITUAL & SURVIVAL" />
        <section id="gameplay" className="space-y-12 mb-20 scroll-mt-24">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
            <div className="bg-stone-900/30 p-6 border border-stone-800">
              <h3 className="text-xl text-stone-300 mb-3 font-mincho">本命燈：你的生命不是血條</h3>
              <p className="text-sm leading-relaxed text-stone-500">
                每位玩家在遊戲開始時會獲得一盞「本命燈」——它不是 UI 裝飾，它是你與生命的連結：
              </p>
              <ul className="mt-4 space-y-2 text-sm text-stone-500 list-disc pl-5">
                <li>🔥 燈火明亮：鬼魅無法近身</li>
                <li>🕯️ 燈火搖曳：黑暗中的事物開始蠢動</li>
                <li>💀 燈火熄滅：你要付出代價（不一定是立即死亡）</li>
              </ul>
              <p className="mt-4 text-xs font-mono text-stone-600">
                （可做成一張圖／一段 GIF，放在募資頁「快速概覽」區塊。）
              </p>
            </div>

            <div className="bg-stone-900/30 p-6 border border-stone-800">
              <h3 className="text-xl text-stone-300 mb-3 font-mincho">儀式模擬：你可以在這裡「試試看」</h3>
              <p className="text-sm leading-relaxed text-stone-500">
                募資頁面要的是信任。最直接的方法：把核心互動做成可玩 demo（哪怕只有一個儀式房間）。下面是示意版：
              </p>
              <div className="mt-6">
                <RitualCanvas fearLevel={fearLevel} debuffs={debuffs} onRitualComplete={handleRitualOutcome} />
              </div>
            </div>
          </div>

          <div className="border-t border-red-900/30 pt-10 text-center">
            <h4 className="text-2xl font-mincho mb-4 text-stone-400">結局不是獎勵，是帳單</h4>
            <div className="flex flex-wrap justify-center gap-4 text-sm font-mono text-stone-600">
              <span className="px-3 py-1 border border-stone-800 rounded">BAD: 連線未斷</span>
              <span className="px-3 py-1 border border-stone-800 rounded">NORMAL: 僅存一人</span>
              <span className="px-3 py-1 border border-red-900/50 text-red-900/70 rounded">TRUE: 杏林新生</span>
            </div>
          </div>
        </section>

        {/* Aesthetics */}
        <SectionHeader title="聲光美學" subtitle="AESTHETICS" />
        <section id="aesthetics" className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20 scroll-mt-24">
          <div className="bg-stone-900/30 p-6 border-t border-stone-800">
            <h3 className="text-xl text-stone-300 mb-4 flex items-center gap-2">
              <Sparkles size={20} /> 視覺識別（建議色票）
            </h3>
            <p className="text-sm leading-relaxed text-stone-500">
              血黑 #1A0000、暗紅 #8B0000、深黑 #0D0D0D、灰白 #C8C8C8、符咒黃 #FFD700。也可以加入朱砂紅與香灰灰，做出「廟宇 + 醫院」的混血恐怖感。
            </p>
            <div className="mt-6 grid grid-cols-5 gap-2">
              {['#1A0000', '#8B0000', '#0D0D0D', '#C8C8C8', '#FFD700'].map(c => (
                <div key={c} className="h-10 border border-stone-800" style={{ backgroundColor: c }} title={c}></div>
              ))}
            </div>
          </div>

          <div className="bg-stone-900/30 p-6 border-t border-stone-800">
            <h3 className="text-xl text-stone-300 mb-4 flex items-center gap-2">
              <FileText size={20} /> 字體與 UI 語氣
            </h3>
            <p className="text-sm leading-relaxed text-stone-500">
              內文建議用 Noto Serif TC（你目前已套用）。標題可導入「故障/破碎明朝」字體（例如 Glitch 明朝類型），搭配 VHS 掃描線、RGB 色偏、訊號中斷等效果，讓募資頁面也像一個「被污染的介面」。
            </p>
            <p className="mt-4 text-xs font-mono text-stone-600">
              小技巧：文字顫抖不要常駐，只有在「連線成功」或「燈火搖曳」時才發作，才會有效。
            </p>
          </div>
        </section>

        {/* Team */}
        <SectionHeader title="團隊介紹" subtitle="WHO WE ARE" />
        <section id="team" className="mb-20 scroll-mt-24">
          <div className="bg-stone-900/30 border border-stone-800 p-6">
            <div className="flex items-start justify-between gap-6 flex-col md:flex-row">
              <div>
                <h3 className="text-xl font-mincho text-stone-200 flex items-center gap-2">
                  <Users size={20} className="text-red-800" />
                  團隊與過往作品
                </h3>
                <p className="text-stone-500 text-sm mt-2">
                  募資頁面最怕的不是「做不到」，而是「看起來像做不到」。建議放照片、履歷、過往作品連結，以及每個人負責的模組。
                </p>
              </div>
              <button className="px-4 py-2 border border-stone-700 text-stone-400 hover:text-stone-200 hover:border-stone-500 transition-colors text-xs font-mono flex items-center gap-2">
                <ExternalLink size={14} />
                填入作品集 / GitHub / ArtStation
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
              {[
                { role: '製作人 / 企劃', note: '（請填：代表作品、專長、分工）' },
                { role: '程式 / 系統', note: '（請填：引擎、網路、工具鏈）' },
                { role: '美術 / 聲音', note: '（請填：風格、管線、合作夥伴）' }
              ].map((m, i) => (
                <div key={i} className="bg-black/30 border border-stone-800 p-5">
                  <div className="text-sm font-bold text-stone-200">{m.role}</div>
                  <div className="text-xs text-stone-600 mt-2 font-mono">{m.note}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Rewards */}
        <SectionHeader title="獎勵方案" subtitle="REWARD TIERS" />
        <section id="rewards" className="mb-20 scroll-mt-24">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {rewards.map((r, i) => (
              <div
                key={i}
                className={`border p-4 bg-stone-900/30 transition-colors ${
                  i === rewards.length - 1
                    ? 'border-red-900/60 hover:border-red-700'
                    : 'border-stone-800 hover:border-stone-600'
                }`}
              >
                <div className="text-xs font-mono text-stone-500">TIER {i + 1}</div>
                <div className="mt-2 text-lg font-bold text-stone-200">{r.price}</div>
                <div className="text-sm text-red-300 mt-1 flex items-center gap-2">
                  <Gift size={16} className="opacity-80" />
                  {r.name}
                </div>
                <div className="text-xs font-mono text-stone-600 mt-2">{r.tag}</div>

                <ul className="mt-4 space-y-2 text-xs text-stone-500 list-disc pl-5">
                  {r.includes.map((x, idx) => (
                    <li key={idx}>{x}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="mt-8 bg-stone-950/60 border border-stone-800 p-6">
            <div className="text-sm font-bold text-stone-200 flex items-center gap-2">
              <Skull size={18} className="text-red-800" />
              恐怖專屬回饋（更會讓人掏錢的那種）
            </div>
            <div className="mt-3 text-sm text-stone-500">
              「贊助者鬼魂/NPC」、「命名房間」、「客製化死亡場景」、「獨家世界觀文件」、「受詛咒典藏包裝」、「實體道具（符咒、老照片）」——這些比單純周邊更有故事性，也更值得分享。
            </div>
          </div>
        </section>

        {/* Roadmap */}
        <SectionHeader title="時程與路線圖" subtitle="ROADMAP" />
        <section id="roadmap" className="mb-20 scroll-mt-24">
          <div className="bg-stone-900/30 border border-stone-800 p-6">
            <div className="flex items-start gap-3">
              <CalendarClock size={20} className="text-red-800 mt-1" />
              <div>
                <h3 className="font-mincho text-xl text-stone-200">一個務實的承諾，比十個華麗的願望更可怕</h3>
                <p className="text-stone-500 text-sm mt-2">
                  建議先估算開發時間，再加上至少 6 個月緩衝；募資期間每週更新，結束後每月更新一次。把溝通做成「固定儀式」，你會得到玩家信任。
                </p>
              </div>
            </div>

            <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
              {[
                { t: 'MVP Demo', d: '核心儀式 + 1 區域 + 1 鬼種' },
                { t: '垂直切片', d: '教學關卡 + 本命燈完整循環 + 連線事件' },
                { t: 'Alpha / 回饋', d: '封測、優化、加入贊助者內容' },
                { t: '發售', d: '多結局、成就、完整音效/配樂' }
              ].map((x, i) => (
                <div key={i} className="bg-black/30 border border-stone-800 p-5">
                  <div className="text-sm font-bold text-stone-200">{x.t}</div>
                  <div className="text-xs text-stone-600 mt-2 font-mono leading-relaxed">{x.d}</div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ */}
        <SectionHeader title="FAQ" subtitle="COMMON QUESTIONS" />
        <section id="faq" className="mb-10 scroll-mt-24">
          <div className="bg-stone-900/30 border border-stone-800 p-6">
            <div className="flex items-center gap-2 text-stone-200 font-bold mb-6">
              <HelpCircle size={18} className="text-red-800" />
              先把疑慮處理掉，玩家才敢把錢掏出來
            </div>

            <div className="space-y-5">
              {faq.map((item, i) => (
                <div key={i} className="border-l-2 border-stone-800 pl-4">
                  <div className="text-sm text-stone-200 font-bold">{item.q}</div>
                  <div className="text-sm text-stone-500 mt-2 leading-relaxed">{item.a}</div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Floating Interactive Element */}
      <SpectralPhone currentSection={currentSection} onFearIncrease={handleFearIncrease} onAddDebuff={addDebuff} />

      {/* Footer */}
      <footer className="bg-black py-12 text-center text-stone-700 font-mono text-xs border-t border-stone-900 relative z-10">
        <p>靈異連線 PROJECT © 2024</p>
        <p className="mt-2">Use headphones for maximum immersion.</p>
        <p className="mt-2 text-stone-800">
          （提示：點文中「證據」標記可解鎖調查筆記。你越好奇，連線越穩。）
        </p>
      </footer>
    </div>
  );
};

export default App;
