import React from 'react';

const SectionHeader: React.FC<{ title: string; subtitle: string }> = ({ title, subtitle }) => (
  <div className="mb-8 mt-16 border-l-2 border-red-900 pl-4">
    <h2 className="text-3xl font-mincho font-bold text-stone-200 tracking-wider mb-1">{title}</h2>
    <p className="text-red-900/70 uppercase text-sm font-bold tracking-[0.2em]">{subtitle}</p>
  </div>
);

export default SectionHeader;
