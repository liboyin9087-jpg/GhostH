import React, { useEffect, useRef } from 'react';
import { Activity, HeartPulse } from 'lucide-react';
import { PlayerDebuff } from '../types';

interface FearMeterProps {
  fearLevel: number; // 0 to 100
  debuffs?: PlayerDebuff[];
}

const FearMeter: React.FC<FearMeterProps> = ({ fearLevel, debuffs = [] }) => {
  // Check active debuffs
  const hasBlurredVision = debuffs.includes('BLURRED_VISION');
  const hasSpiritPresence = debuffs.includes('SPIRIT_PRESENCE');

  // Calculate pulse speed based on fear (lower duration = faster)
  // Spirit presence increases perceived heart rate
  const pulseSpeed = Math.max(0.3, (2 - (fearLevel / 50)) / (hasSpiritPresence ? 1.5 : 1)); 
  
  // Calculate visual distortion values
  // Blurred vision maxes out blur instantly
  const blurAmount = hasBlurredVision ? 10 : Math.max(0, (fearLevel - 30) / 20); 
  const vignetteOpacity = fearLevel / 100;
  const saturation = 100 - (fearLevel / 2); // Colors drain as fear rises

  // Audio Refs
  const audioCtxRef = useRef<AudioContext | null>(null);
  const nextBeatTimeRef = useRef<number>(0);
  const isPlayingRef = useRef<boolean>(false);
  const whiteNoiseNodeRef = useRef<GainNode | null>(null);
  const fearLevelRef = useRef(fearLevel); // To access fresh state in loop
  const debuffsRef = useRef(debuffs);

  // Keep ref synced
  useEffect(() => {
    fearLevelRef.current = fearLevel;
    debuffsRef.current = debuffs;
    
    // Update White Noise Volume based on fear and debuffs
    if (whiteNoiseNodeRef.current && audioCtxRef.current) {
        // Static starts becoming audible at fear level 10, max volume at 100 is 0.05
        // If Spirit Presence is active, boost volume significantly
        let baseVol = fearLevel > 10 ? (fearLevel - 10) / 90 * 0.05 : 0;
        if (debuffs.includes('SPIRIT_PRESENCE')) baseVol += 0.05;
        
        whiteNoiseNodeRef.current.gain.setTargetAtTime(baseVol, audioCtxRef.current.currentTime, 0.5);
    }
  }, [fearLevel, debuffs]);

  // Audio Loop Effect
  useEffect(() => {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    const ctx = new AudioContextClass();
    audioCtxRef.current = ctx;
    isPlayingRef.current = true;
    nextBeatTimeRef.current = ctx.currentTime + 0.1;

    // --- White Noise Setup ---
    const bufferSize = 2 * ctx.sampleRate;
    const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
    }
    const whiteNoise = ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;
    const noiseGain = ctx.createGain();
    noiseGain.gain.value = 0; // Start silent
    whiteNoise.connect(noiseGain);
    noiseGain.connect(ctx.destination);
    whiteNoise.start(0);
    whiteNoiseNodeRef.current = noiseGain;

    const scheduleBeats = () => {
      if (!isPlayingRef.current || !ctx) return;
      if (ctx.state === 'suspended') ctx.resume();

      // Lookahead: schedule beats for the next 0.1 seconds
      while (nextBeatTimeRef.current < ctx.currentTime + 0.1) {
        const currentFear = fearLevelRef.current;
        const currentDebuffs = debuffsRef.current;
        
        // Play heartbeat if fear is elevated OR spirit is present
        if (currentFear > 20 || currentDebuffs.includes('SPIRIT_PRESENCE')) {
            playHeartbeat(ctx, nextBeatTimeRef.current, currentFear);
        }

        // Calculate next beat interval based on fear
        // Map 0-100 fear to 60-180 BPM
        let bpm = 60 + (currentFear * 1.2);
        if (currentDebuffs.includes('SPIRIT_PRESENCE')) bpm += 30; // Heart races with ghosts

        const secondsPerBeat = 60 / bpm;
        nextBeatTimeRef.current += secondsPerBeat;
      }
      requestAnimationFrame(scheduleBeats);
    };

    const playHeartbeat = (c: AudioContext, time: number, intensity: number) => {
        const osc = c.createOscillator();
        const gain = c.createGain();
        osc.connect(gain);
        gain.connect(c.destination);

        // Low frequency thud
        osc.frequency.setValueAtTime(100 + (intensity/2), time);
        osc.frequency.exponentialRampToValueAtTime(50, time + 0.1);
        
        // Volume based on intensity
        const volume = Math.min(0.5, (intensity - 20) / 100);
        gain.gain.setValueAtTime(volume, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.15);

        osc.start(time);
        osc.stop(time + 0.2);
    };

    scheduleBeats();

    return () => {
      isPlayingRef.current = false;
      if (ctx.state !== 'closed') ctx.close();
    };
  }, []); 
  
  return (
    <>
      {/* Global Screen Distortion Overlay */}
      <div 
        className="fixed inset-0 pointer-events-none z-0 transition-all duration-1000 ease-out"
        style={{
          boxShadow: `inset 0 0 ${fearLevel * 2}px rgba(0,0,0, ${vignetteOpacity})`,
          backdropFilter: `blur(${blurAmount}px) contrast(${100 + fearLevel/2}%)`,
          filter: `saturate(${saturation}%) sepia(${fearLevel * 0.5}%)`,
        }}
      >
        {/* Chromatic Aberration Effect at High Fear */}
        {(fearLevel > 60 || hasSpiritPresence) && (
           <div className="absolute inset-0 opacity-20 animate-pulse bg-red-900 mix-blend-overlay"></div>
        )}
      </div>

      {/* HUD Widget */}
      <div className="fixed bottom-4 left-4 z-50 flex items-center gap-4 pointer-events-none">
        <div className="relative">
          <div 
            className="absolute inset-0 bg-red-600 rounded-full blur-xl transition-opacity duration-300"
            style={{ opacity: fearLevel / 100 }}
          ></div>
          <HeartPulse 
            size={48} 
            className="text-red-600 relative z-10" 
            style={{ 
              animation: `pulse ${pulseSpeed}s infinite`,
              filter: `drop-shadow(0 0 ${fearLevel/5}px red)`
            }}
          />
        </div>
        
        <div className="flex flex-col">
          <div className="flex items-center gap-2 text-red-700 font-mono text-xs mb-1">
            <Activity size={12} className="animate-bounce" />
            <span>PSYCHE STABILITY</span>
          </div>
          
          {/* Bar Container */}
          <div className="w-48 h-2 bg-stone-900 border border-stone-700 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-stone-600 to-red-600 transition-all duration-500 ease-out"
              style={{ width: `${fearLevel}%` }}
            ></div>
          </div>
          
          {/* Status Text */}
          <div className="text-right text-[10px] text-stone-500 font-mono mt-1">
            {fearLevel < 30 ? "STABLE" : fearLevel < 70 ? "ELEVATED" : "CRITICAL"}
          </div>
        </div>
      </div>
      
      {/* CSS for custom pulse animation if not in tailwind config */}
      <style>{`
        @keyframes pulse {
          0%, 100% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.1); opacity: 0.8; }
        }
      `}</style>
    </>
  );
};

export default FearMeter;