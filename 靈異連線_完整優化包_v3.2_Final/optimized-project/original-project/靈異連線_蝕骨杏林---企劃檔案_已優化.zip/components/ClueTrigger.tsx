import React from 'react';
import { Eye, EyeOff } from 'lucide-react';

type Props = {
  id: string;
  found: boolean;
  onReveal: (id: string) => void;
  className?: string;
  labelFound?: string;
  labelHidden?: string;
};

const ClueTrigger: React.FC<Props> = ({
  id,
  found,
  onReveal,
  className = '',
  labelFound = '證據已收錄',
  labelHidden = '發現證據'
}) => {
  return (
    <button
      type="button"
      onClick={() => onReveal(id)}
      className={`inline-flex items-center gap-1 mx-1 px-2 py-0.5 rounded border text-[11px] font-mono transition-colors ${
        found
          ? 'border-stone-800 text-stone-600 bg-black/20 hover:border-stone-700'
          : 'border-red-900/60 text-red-300 bg-red-950/10 hover:bg-red-950/20 hover:border-red-700'
      } ${className}`}
      title={found ? labelFound : labelHidden}
    >
      {found ? <EyeOff size={12} /> : <Eye size={12} />}
      <span>{found ? labelFound : labelHidden}</span>
    </button>
  );
};

export default ClueTrigger;
