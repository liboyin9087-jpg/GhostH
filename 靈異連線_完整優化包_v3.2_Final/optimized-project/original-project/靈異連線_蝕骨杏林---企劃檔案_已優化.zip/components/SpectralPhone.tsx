import React, { useState, useEffect, useRef } from 'react';
import { Phone, PhoneOff, MessageSquare, Signal } from 'lucide-react';
import { generateGhostMessage } from '../services/geminiService';
import { PlayerDebuff } from '../types';

interface SpectralPhoneProps {
  currentSection: string;
  onFearIncrease?: (amount: number) => void;
  onAddDebuff?: (debuff: PlayerDebuff, duration: number) => void;
}

const SpectralPhone: React.FC<SpectralPhoneProps> = ({ currentSection, onFearIncrease, onAddDebuff }) => {
  const [isRinging, setIsRinging] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{id: number, text: string, sender: 'ghost' | 'me'}[]>([]);
  const [loading, setLoading] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);

  // Randomly trigger a "ring"
  useEffect(() => {
    const triggerRing = () => {
      if (Math.random() > 0.6 && !isOpen && !isRinging) { // Increased frequency slightly
        setIsRinging(true);
        playRingSound();
        if (onFearIncrease) onFearIncrease(5); // Ringing itself causes mild stress
      }
    };
    const interval = setInterval(triggerRing, 12000); 
    return () => clearInterval(interval);
  }, [isOpen, isRinging, onFearIncrease]);

  const playRingSound = () => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const ctx = audioContextRef.current;
    if (ctx && ctx.state !== 'closed') {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.frequency.value = 440; // A4
      osc.type = 'sawtooth';
      gain.gain.setValueAtTime(0.1, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
      osc.start();
      osc.stop(ctx.currentTime + 0.5);
    }
  };

  const handleAnswer = async () => {
    setIsRinging(false);
    setIsOpen(true);
    setLoading(true);
    
    if (onFearIncrease) onFearIncrease(15); // Answering causes big fear spike
    if (onAddDebuff) onAddDebuff('SPIRIT_PRESENCE', 10000); // 10s of spirit presence
    
    // Call Gemini
    const ghostText = await generateGhostMessage(currentSection);
    
    setMessages(prev => [...prev, {
      id: Date.now(),
      text: ghostText,
      sender: 'ghost'
    }]);
    setLoading(false);
  };

  const handleDecline = () => {
    setIsRinging(false);
    if (onFearIncrease) onFearIncrease(5); // Hanging up also causes lingering stress
  };

  const closePhone = () => {
    setIsOpen(false);
  };

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col items-end pointer-events-none">
      {/* Phone Body */}
      <div 
        className={`pointer-events-auto transition-all duration-500 ease-out transform ${
          isOpen ? 'translate-y-0 opacity-100' : 'translate-y-12 opacity-0'
        } ${isOpen ? 'h-96 w-72' : 'h-0 w-0 overflow-hidden'}`}
      >
        <div className="bg-neutral-900 border border-neutral-700 rounded-2xl shadow-2xl h-full flex flex-col relative overflow-hidden">
            {/* Screen Glare */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/5 to-transparent pointer-events-none z-20"></div>
            
            {/* Status Bar */}
            <div className="bg-black/50 p-2 flex justify-between items-center text-xs text-neutral-400">
                <span><Signal size={12} /> 4G (Cursed)</span>
                <span>23:49</span>
            </div>

            {/* Chat Area */}
            <div className="flex-1 p-4 overflow-y-auto font-mono text-sm space-y-3 bg-neutral-900/90 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]">
                {messages.length === 0 && !loading && (
                    <div className="text-center text-neutral-600 mt-10 italic">
                        無訊號...
                    </div>
                )}
                {messages.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[80%] p-2 rounded ${
                            msg.sender === 'me' 
                            ? 'bg-neutral-700 text-neutral-200' 
                            : 'bg-red-900/30 border border-red-900/50 text-red-200 animate-pulse'
                        }`}>
                            {msg.text}
                        </div>
                    </div>
                ))}
                {loading && (
                    <div className="text-red-500 text-xs animate-pulse">對方正在輸入...</div>
                )}
            </div>

            {/* Action Bar */}
            <div className="p-3 bg-black flex justify-center border-t border-neutral-800">
                <button 
                    onClick={closePhone}
                    className="p-3 rounded-full bg-red-600 hover:bg-red-700 text-white transition-colors"
                >
                    <PhoneOff size={20} />
                </button>
            </div>
        </div>
      </div>

      {/* Ringing Notification / Trigger Button */}
      {!isOpen && (
        <button
          onClick={isRinging ? handleAnswer : () => setIsOpen(true)}
          className={`pointer-events-auto mt-4 p-4 rounded-full shadow-lg transition-all duration-300 flex items-center gap-3 ${
            isRinging 
              ? 'bg-red-600 hover:bg-red-700 animate-bounce' 
              : 'bg-neutral-800 hover:bg-neutral-700 border border-neutral-600'
          }`}
        >
          {isRinging ? <Phone className="text-white" /> : <MessageSquare className="text-neutral-400" />}
          {isRinging && <span className="text-white font-bold pr-2">來電中... (UNKNOWN)</span>}
        </button>
      )}
    </div>
  );
};

export default SpectralPhone;