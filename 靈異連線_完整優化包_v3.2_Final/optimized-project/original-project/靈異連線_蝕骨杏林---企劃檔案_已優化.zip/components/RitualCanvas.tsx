import React, { useState } from 'react';
import { Flame, PenTool, Skull, Scroll, AlertTriangle, ShieldAlert, XCircle, Activity } from 'lucide-react';
import { interpretRitual } from '../services/geminiService';
import { RitualResult, PlayerDebuff } from '../types';

interface RitualCanvasProps {
  fearLevel: number;
  debuffs: PlayerDebuff[];
  onRitualComplete: (result: RitualResult) => void;
}

const RitualCanvas: React.FC<RitualCanvasProps> = ({ fearLevel, debuffs = [], onRitualComplete }) => {
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  const [outcome, setOutcome] = useState<RitualResult | null>(null);
  const [loading, setLoading] = useState(false);

  // Check if hands are shaking due to debuff or high fear
  const isShaky = debuffs.includes('SHAKY_HANDS') || fearLevel > 70;

  const items = [
    { id: 'red_string', name: '紅線 (Red String)', icon: <div className="w-4 h-4 bg-red-600 rounded-full" /> },
    { id: 'talisman', name: '符紙 (Talisman)', icon: <Scroll size={16} className="text-yellow-600" /> },
    { id: 'hair', name: '死者頭髮 (Hair)', icon: <div className="w-4 h-4 bg-black rounded-full border border-gray-600" /> },
    { id: 'knife', name: '法刀 (Ritual Knife)', icon: <PenTool size={16} className="text-gray-400" /> },
  ];

  const toggleItem = (id: string) => {
    setSelectedItems(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
    setOutcome(null); // Reset outcome on change
  };

  const performRitual = async () => {
    setLoading(true);
    setOutcome(null);
    
    // Higher fear or shaking hands makes it slower
    if (fearLevel > 70 || isShaky) {
      await new Promise(r => setTimeout(r, 1500));
    }

    const result = await interpretRitual(selectedItems, "Pacify the resentful spirit");
    setOutcome(result);
    setLoading(false);
    onRitualComplete(result);
  };

  const opacityClass = fearLevel > 80 ? 'opacity-50' : 'opacity-100';

  // Dynamic styles based on outcome type
  const getContainerStyle = () => {
    if (!outcome) return 'border-stone-800 bg-stone-900/50';
    switch (outcome.type) {
      case 'CRITICAL': return 'border-red-600 bg-red-950/40';
      case 'WARNING': return 'border-orange-700 bg-stone-900/50';
      case 'SUCCESS': return 'border-emerald-900 bg-emerald-950/20';
      default: return 'border-stone-800';
    }
  };

  return (
    <div className="w-full relative">
      <style>{`
        @keyframes subtle-shake {
          0% { transform: translate(0, 0); }
          25% { transform: translate(1px, 1px); }
          50% { transform: translate(-1px, -1px); }
          75% { transform: translate(-1px, 1px); }
          100% { transform: translate(0, 0); }
        }
        @keyframes violent-shake {
          0% { transform: translate(1px, 1px) rotate(0deg); }
          10% { transform: translate(-1px, -2px) rotate(-1deg); }
          20% { transform: translate(-3px, 0px) rotate(1deg); }
          30% { transform: translate(3px, 2px) rotate(0deg); }
          40% { transform: translate(1px, -1px) rotate(1deg); }
          50% { transform: translate(-1px, 2px) rotate(-1deg); }
          60% { transform: translate(-3px, 1px) rotate(0deg); }
          70% { transform: translate(3px, 1px) rotate(-1deg); }
          80% { transform: translate(-1px, -1px) rotate(1deg); }
          90% { transform: translate(1px, 2px) rotate(0deg); }
          100% { transform: translate(1px, -2px) rotate(-1deg); }
        }
        .cracked-overlay {
            background-image: url("https://www.transparenttextures.com/patterns/cracked-glass.png");
            opacity: 0.5;
            mix-blend-mode: overlay;
        }
      `}</style>

      <div 
        className={`w-full border rounded-lg p-6 relative overflow-hidden group transition-all duration-500 ${getContainerStyle()}`}
        style={{
            animation: outcome?.type === 'CRITICAL' || isShaky 
                ? `violent-shake 0.5s infinite` 
                : fearLevel > 20 
                    ? `subtle-shake 2s infinite` 
                    : 'none'
        }}
      >
          {/* Critical Failure Overlay */}
          {outcome?.type === 'CRITICAL' && (
              <div className="absolute inset-0 z-20 pointer-events-none flex items-center justify-center bg-red-950/50 cracked-overlay">
                  <div className="border-4 border-red-600 p-4 text-red-600 font-black text-4xl rotate-12 animate-pulse bg-black/80">
                      SEAL BROKEN
                  </div>
              </div>
          )}

          {/* Background Icon */}
          <div className={`absolute top-0 right-0 p-4 opacity-10 transition-transform duration-700 ${outcome?.type === 'CRITICAL' ? 'scale-150 text-red-500' : 'text-stone-500'}`}>
              {outcome?.type === 'CRITICAL' ? <AlertTriangle size={120} /> : <Skull size={120} />}
          </div>
          
          <h3 className="text-xl font-mincho font-bold text-stone-300 mb-4 border-b border-red-900/30 pb-2 flex justify-between items-center">
              <span>儀式模擬 (Ritual)</span>
              {outcome && (
                 <span className={`text-xs font-mono px-2 py-1 rounded border ${
                    outcome.type === 'CRITICAL' ? 'border-red-500 text-red-500' : 
                    outcome.type === 'SUCCESS' ? 'border-emerald-800 text-emerald-500' : 
                    'border-orange-800 text-orange-500'
                 }`}>
                    STATUS: {outcome.type}
                 </span>
              )}
          </h3>
          
          {isShaky && (
            <p className="text-red-500 text-xs font-mono animate-pulse mb-2 flex items-center gap-1">
                <Activity size={12} />
                WARNING: HANDS TREMBLING. DEXTERITY REDUCED.
            </p>
          )}

          <div className={`grid grid-cols-2 md:grid-cols-4 gap-4 mb-6 transition-opacity duration-500 ${opacityClass}`}>
              {items.map(item => (
                  <button
                      key={item.id}
                      onClick={() => toggleItem(item.id)}
                      disabled={outcome?.type === 'CRITICAL'}
                      className={`p-4 border rounded flex flex-col items-center gap-2 transition-all ${
                          selectedItems.includes(item.id)
                          ? 'bg-red-900/20 border-red-800 text-red-200'
                          : 'bg-stone-950 border-stone-800 text-stone-500 hover:border-stone-600'
                      } ${outcome?.type === 'CRITICAL' ? 'grayscale opacity-50 cursor-not-allowed' : ''}`}
                  >
                      {item.icon}
                      <span className="text-sm font-serif">{item.name}</span>
                  </button>
              ))}
          </div>

          <div className="flex justify-center mb-6">
              <button
                  onClick={performRitual}
                  disabled={loading || selectedItems.length === 0 || outcome?.type === 'CRITICAL'}
                  className={`px-8 py-3 border rounded font-serif tracking-widest transition-all flex items-center gap-2 disabled:opacity-50 ${
                     outcome?.type === 'CRITICAL' 
                     ? 'bg-red-900 text-white border-red-500 hover:bg-red-800' 
                     : 'bg-stone-800 hover:bg-red-900 border-stone-600 text-stone-200'
                  }`}
              >
                  {loading ? <Flame className="animate-spin" /> : <Flame />}
                  {loading ? "燒化中..." : "起壇燒化 (Initiate)"}
              </button>
          </div>

          {outcome && (
              <div className={`p-4 border-l-4 font-serif leading-relaxed animate-in fade-in slide-in-from-bottom-4 duration-700 relative z-10 ${
                  outcome.type === 'CRITICAL' ? 'bg-red-950/80 border-red-600 text-red-200 shadow-lg shadow-red-900/20' :
                  outcome.type === 'SUCCESS' ? 'bg-emerald-950/30 border-emerald-700 text-emerald-100' :
                  'bg-orange-950/30 border-orange-700 text-orange-200'
              }`}>
                  <p className="italic mb-2">"{outcome.message}"</p>
                  
                  {/* Consequence / Debuff Tag */}
                  <div className="flex items-center gap-2 mt-4 pt-4 border-t border-white/10">
                    <ShieldAlert size={16} />
                    <span className="text-xs font-mono uppercase tracking-widest">
                        CONSEQUENCE: <span className="font-bold">{outcome.consequence}</span>
                    </span>
                  </div>
              </div>
          )}
      </div>
    </div>
  );
};

export default RitualCanvas;