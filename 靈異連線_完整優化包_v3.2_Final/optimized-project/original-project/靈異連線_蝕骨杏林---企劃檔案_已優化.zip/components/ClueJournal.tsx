import React, { useState } from 'react';
    import { BookOpen, X, Search, FileImage, FileText } from 'lucide-react';
    import { Clue } from '../types';
    
    interface ClueJournalProps {
      clues: Clue[];
      isOpen: boolean;
      onClose: () => void;
    }
    
    const ClueJournal: React.FC<ClueJournalProps> = ({ clues, isOpen, onClose }) => {
      const [selectedClue, setSelectedClue] = useState<Clue | null>(null);
    
      if (!isOpen) return null;
    
      const foundClues = clues.filter(c => c.found);
    
      return (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4">
          <div className="w-full max-w-4xl h-[80vh] bg-stone-900 border border-stone-700 flex flex-col md:flex-row shadow-2xl overflow-hidden relative">
            
            {/* Close Button */}
            <button 
              onClick={onClose}
              className="absolute top-4 right-4 z-50 text-stone-500 hover:text-red-500 transition-colors"
            >
              <X size={24} />
            </button>
    
            {/* Sidebar List */}
            <div className="w-full md:w-1/3 bg-black/40 border-r border-stone-800 flex flex-col">
              <div className="p-6 border-b border-stone-800">
                <h2 className="text-xl font-mincho font-bold text-stone-200 flex items-center gap-2">
                  <BookOpen size={20} className="text-red-800" />
                  調查筆記 (Evidence)
                </h2>
                <p className="text-xs text-stone-500 mt-2 font-mono">
                  COLLECTED: {foundClues.length}/{clues.length}
                </p>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-2 no-scrollbar">
                {foundClues.length === 0 ? (
                  <div className="text-stone-600 text-sm italic text-center mt-10">
                    尚未收集到任何證據...
                  </div>
                ) : (
                  foundClues.map(clue => (
                    <button
                      key={clue.id}
                      onClick={() => setSelectedClue(clue)}
                      className={`w-full text-left p-3 rounded border transition-all ${
                        selectedClue?.id === clue.id 
                        ? 'bg-red-900/20 border-red-800 text-red-100' 
                        : 'bg-stone-900/50 border-stone-800 text-stone-400 hover:border-stone-600'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {clue.type === 'photo' ? <FileImage size={16} /> : <FileText size={16} />}
                        <span className="font-serif text-sm truncate">{clue.title}</span>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
    
            {/* Detail View */}
            <div className="flex-1 bg-[url('https://www.transparenttextures.com/patterns/paper.png')] bg-stone-800 p-8 overflow-y-auto relative">
              {selectedClue ? (
                <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
                  <div className="mb-6 pb-4 border-b border-stone-600/30">
                    <span className="text-xs font-mono text-red-400 uppercase tracking-widest border border-red-900/50 px-2 py-1 rounded">
                      TYPE: {selectedClue.type}
                    </span>
                    <h3 className="text-2xl font-mincho font-bold text-stone-200 mt-4">
                      {selectedClue.title}
                    </h3>
                  </div>
                  
                  <div className="prose prose-invert prose-stone max-w-none">
                    <p className="font-serif text-lg leading-loose text-stone-300 whitespace-pre-line">
                      {selectedClue.content}
                    </p>
                    <div className="mt-8 p-4 bg-black/20 rounded border border-stone-700/50">
                      <h4 className="text-xs font-bold text-stone-500 uppercase mb-2">Analysis Note</h4>
                      <p className="text-sm text-stone-400 italic font-mono">
                        {selectedClue.description}
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-stone-600 opacity-50">
                  <Search size={48} className="mb-4" />
                  <p>Select an item to inspect details.</p>
                </div>
              )}
            </div>
    
          </div>
        </div>
      );
    };
    
    export default ClueJournal;