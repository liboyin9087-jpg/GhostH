import React from 'react';

interface GlitchTextProps {
  text: string;
  className?: string;
  intensity?: 'low' | 'high';
}

const GlitchText: React.FC<GlitchTextProps> = ({ text, className = "", intensity = 'low' }) => {
  return (
    <div className={`relative inline-block ${className} group`}>
      <span className="relative z-10">{text}</span>
      <span 
        className={`absolute top-0 left-0 -z-10 w-full h-full text-red-800 opacity-0 group-hover:opacity-70 animate-pulse translate-x-[2px]`}
        aria-hidden="true"
      >
        {text}
      </span>
      {intensity === 'high' && (
        <span 
          className={`absolute top-0 left-0 -z-10 w-full h-full text-cyan-900 opacity-0 group-hover:opacity-70 animate-flicker -translate-x-[2px]`}
          aria-hidden="true"
        >
          {text}
        </span>
      )}
    </div>
  );
};

export default GlitchText;