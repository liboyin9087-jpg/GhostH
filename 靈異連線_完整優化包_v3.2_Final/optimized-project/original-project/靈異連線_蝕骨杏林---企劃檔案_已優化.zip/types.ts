import React from 'react';

export interface RitualItem {
  id: string;
  name: string;
  type: 'material' | 'tool' | 'offering';
  description: string;
}

export type RitualOutcomeType = 'SUCCESS' | 'WARNING' | 'CRITICAL';

export interface RitualResult {
  type: RitualOutcomeType;
  message: string;
  consequence?: string; // e.g., "Shadow Stalker Summoned" or "Karma +50"
}

export type PlayerDebuff = 'SHAKY_HANDS' | 'BLURRED_VISION' | 'SPIRIT_PRESENCE';

export enum GameState {
  LOCKED = 'LOCKED',
  BROWSING = 'BROWSING',
  HAUNTED = 'HAUNTED',
}

export interface ChatMessage {
  sender: 'user' | 'ghost' | 'system';
  content: string;
  timestamp: Date;
}

export interface ProposalSection {
  id: string;
  title: string;
  content: React.ReactNode;
}

export interface Clue {
  id: string;
  title: string;
  type: 'document' | 'photo' | 'object';
  description: string;
  content: string; // The lore text or image URL
  found: boolean;
}